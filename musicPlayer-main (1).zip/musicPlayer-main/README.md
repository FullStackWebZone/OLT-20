# Music Player

Simple web based music player that is pre-loaded with some of my favorite OST from a few different Animes.

Front end was developed with basic HTML and CSS. JavaScript was incorporated to create play, pause and skip functions. 