

// open toggle in dropdown

document.getElementsByClassName('open_menu')[0].addEventListener('click',function () {
    document.getElementById('menuMd').setAttribute('style','width: 250px')
    

});
document.getElementsByClassName('close_menu')[0].addEventListener('click',function () {
    document.getElementById('menuMd').setAttribute('style','width: 0px')
});

// close toggle in dropdown





    // AOS Instance
    AOS.init();







    Link In descriptions
