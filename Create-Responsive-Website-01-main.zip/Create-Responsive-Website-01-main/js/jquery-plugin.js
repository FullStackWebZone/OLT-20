jQuery(document).ready(function( $ ) {
    $('.counter').counterUp({
        delay: 20,
        time: 2000
    });
});