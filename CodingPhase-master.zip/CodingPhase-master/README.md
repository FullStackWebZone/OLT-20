# CodingPhase
A one week challenge to create a landing page for 'HTML Email Developer - Career Bundle' course from Coding Phase LLC.
