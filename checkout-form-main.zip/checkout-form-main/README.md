# Transition Checkout form
<h3 align="center">Transition Checkout Form Design</h3>
<ol>
<li>HTML</li>
<li>CSS</li>
<li>JavaScript</li>
  - JavaScript library cleave.js
</ol>
<h4> Feature</h4>
<ul>
<li>Credit card number formatting With auto text Delimiter</li>
<li> When fill in the account number, the card type and the two numbers match, then the active class will be added and the icon will be selected</li>
</ul>
